import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class myMapper extends Mapper<myKey, myValue, Text, DoubleWritable> {
	
	public void map(myKey inpK, myValue inpV, Context c) throws IOException, InterruptedException{
	
		 double amt = inpV.getAmt();
		 c.write(inpK.getid(), new DoubleWritable(amt));
		
	  	   }
		
	}


