

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class myreducer extends Reducer<Text, DoubleWritable, Text, Text>{
    public void reduce(Text inpk, Iterable<DoubleWritable> inpv, Context c) throws IOException, InterruptedException{
  	   int count=0;
  	   double sum=0;
  	   
  	 for(DoubleWritable x: inpv)
  	 {
  		   count++;
  		   sum = sum + x.get();
  	   }
  		   
  	   c.write(inpk, new Text(sum+" "+count));
     }
 }