import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class myValue implements Writable{
	DoubleWritable amt;
	
	public myValue(){
		this.amt = new DoubleWritable();
	}
	public myValue(DoubleWritable amt){
		this.amt = amt;
	};
	
	@Override
	public void readFields(DataInput arg0) throws IOException {
		amt.readFields(arg0);
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		amt.write(arg0);
	}
	
	public void setAmt(DoubleWritable amt){
		this.amt=amt;
	}
	public Double getAmt(){
		return amt.get();
	}

}
