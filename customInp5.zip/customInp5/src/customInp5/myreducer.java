package customInp5;



import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class myreducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable>{
    public void reduce(Text inpk, Iterable<DoubleWritable> inpv, Context c) throws IOException, InterruptedException{
  	  
  	   double sum=0;
  	   
  	 for(DoubleWritable x: inpv)
  	 {
  		   
  		   sum = sum + x.get();
  	   }
  		   
  	   c.write(inpk, new DoubleWritable(sum));
     }
 }
